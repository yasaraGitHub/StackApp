/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stackapp;

/**
 *
 * @author yasara
 */
public class Stack {
    
    public static void main(String args[]){
    
    }
}

class StackDemo{

private int maxSize;
private int stackData[];
private int top;

public StackDemo(int s){

    this.maxSize=s;
    this.stackData=new int[s];
    this.top=-1;

}

public


}